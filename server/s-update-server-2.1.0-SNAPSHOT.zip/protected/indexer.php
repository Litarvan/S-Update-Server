<?php

    /*
     * Copyright 2015 TheShark34
     *
     * This file is part of S-Update.

     * S-Update is free software: you can redistribute it and/or modify
     * it under the terms of the GNU Lesser General Public License as published by
     * the Free Software Foundation, either version 3 of the License, or
     * (at your option) any later version.
     *
     * S-Update is distributed in the hope that it will be useful,
     * but WITHOUT ANY WARRANTY; without even the implied warranty of
     * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     * GNU Lesser General Public License for more details.
     *
     * You should have received a copy of the GNU Lesser General Public License
     * along with S-Update.  If not, see <http://www.gnu.org/licenses/>.
     */

    if(isset($_GET['request']))
        if($_GET['request'] == 'indexDates')
            index(false);
        else if($_GET['request'] == 'indexMD5')
            index(true);
        else
            home();
    else
        home();

    function index() {

    }

    function home() {

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>S-Update Installer</title>

        <!-- Bootstrap -->
        <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css" rel="stylesheet">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <link href="http://theshark34.github.io/S-Update-Server/style.css" rel="stylesheet">
    </head>

    <body>
        <div class='fulldiv'>
            <div class="center">
                <img src="http://theshark34.github.io/S-Update-Server/logo.png" />
            </div>

            <div class="under-logo">
              <button id="dates" class="submit-button spaced" style="width: 150px;">Date de dernière modification (Rapide)</button>
              <button id="md5" class="submit-button" style="width: 150px;">MD5 (Sécurisé)</button>
            </div>

            <script type="text/javascript">
                document.getElementById("dates").onclick = function () {
                    location.href = "indexer.php?request=indexDates";
                };

                document.getElementById("md5").onclick = function () {
                    location.href = "indexer.php?request=indexMD5";
                };
            </script>
        </div>

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
        <!-- Offical S-Update script -->
        <script src="http://theshark34.github.io/S-Update-Server/supdate.js"></script>

        <!-- Starting Installer -->
        <script> sendRequest("indexer.php", "index", null); </script>
    </body>
</html>

<?php

    }
?>
